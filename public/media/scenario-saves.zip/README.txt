Open Neather Earth Rebuilt and choose Import save. Select one of these JSON files.
These are staged encounters; robot combat uses the normal simulation.
For Nuclear Finale, press Space to detonate the selected robot.
Play: https://realill.github.io/neather-earth-rebuilt/
